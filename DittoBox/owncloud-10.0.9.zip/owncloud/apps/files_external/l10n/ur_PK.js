OC.L10N.register(
    "files_external",
    {
    "Personal" : "شخصی",
    "Username" : "یوزر نیم",
    "Password" : "پاسورڈ",
    "Save" : "حفظ",
    "URL" : "یو ار ایل",
    "Location" : "مقام",
    "Share" : "تقسیم",
    "Name" : "اسم",
    "Delete" : "حذف کریں"
},
"nplurals=2; plural=(n != 1);");
