OC.L10N.register(
    "files_external",
    {
    "Personal" : "વ્યક્તિગત",
    "Delete" : "કાઢો"
},
"nplurals=2; plural=(n != 1);");
