OC.L10N.register(
    "files_external",
    {
    "Personal" : "వ్యక్తిగతం",
    "Username" : "వాడుకరి పేరు",
    "Password" : "సంకేతపదం",
    "Save" : "భద్రపరచు",
    "Name" : "పేరు",
    "Folder name" : "సంచయం పేరు",
    "Delete" : "తొలగించు"
},
"nplurals=2; plural=(n != 1);");
