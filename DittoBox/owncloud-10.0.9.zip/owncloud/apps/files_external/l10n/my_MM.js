OC.L10N.register(
    "files_external",
    {
    "Username" : "သုံးစွဲသူအမည်",
    "Password" : "စကားဝှက်",
    "Location" : "တည်နေရာ"
},
"nplurals=1; plural=0;");
