<?php
$TRANSLATIONS = array(
"Documentation" => "به‌ڵگه‌نامه"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
