OC.L10N.register(
    "firstrunwizard",
    {
    "Get the apps to sync your files" : "Obtingueu les aplicacions per sincronitzar els vostres fitxers",
    "Desktop client" : "Client d'escriptori",
    "Android app" : "aplicació para Android",
    "iOS app" : "aplicació para iOS",
    "Connect your desktop apps to %s" : "Connecteu les aplicacions d'escriptori a %s",
    "Connect your Calendar" : "Connecteu el vostre calendari",
    "Connect your Contacts" : "Connecteu els vostres contactes",
    "Documentation" : "Documentació",
    "Access files via WebDAV" : "Accediu al fitxers mitjançant WebDAV",
    "There’s more information in the <a target=\"_blank\" href=\"%s\">documentation</a> and on our <a target=\"_blank\" href=\"http://owncloud.org\">website</a>." : "Hi ha més informació a la <a target=\"_blank\" href=\"%s\">documentació</a> a la <a target=\"_blank\" href=\"http://owncloud.org\">web</a>."
},
"nplurals=2; plural=(n != 1);");
