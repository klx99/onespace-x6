<?php
$TRANSLATIONS = array(
"Get the apps to sync your files" => "Преземете апликации за синхронизирање на вашите датотеки",
"Connect your Calendar" => "Поврзете го вашикот календар",
"Connect your Contacts" => "Поврзете ги вашите контакти",
"Access files via WebDAV" => "Пристапи до датотеките преку WebDAV",
"Documentation" => "Документација"
);
$PLURAL_FORMS = "nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;";
