OC.L10N.register(
    "firstrunwizard",
    {
    "A safe home for all your data" : "Un endrech segur per totas vòstras donadas",
    "Access & share your files, calendars, contacts, mail & more from any device, on your terms" : "Accedissètz & partejatz vòstres fichièrs, calendièrs, quasernets d'adreças, emails & plan mai encara dempuèi quin periferic que siá, jos vòstras condicions",
    "Get the apps to sync your files" : "Obtenètz las aplicacions que vos permeton de sincronizar vòstres fichièrs",
    "Desktop client" : "Client de burèu",
    "Android app" : "Aplicacion Android",
    "iOS app" : "Aplicacion iOS",
    "Connect your desktop apps to %s" : "Connectatz vòstras aplicacions de burèu a %s",
    "Connect your Calendar" : "Connectatz vòstre calendièr",
    "Connect your Contacts" : "Connectatz vòstres contactes",
    "Documentation" : "Documentacion",
    "Access files via WebDAV" : "Accedissètz a vòstres fichièrs via WebDAV",
    "There’s more information in the <a target=\"_blank\" href=\"%s\">documentation</a> and on our <a target=\"_blank\" href=\"http://owncloud.org\">website</a>." : "D'informacions complementàrias son disponiblas dins <a target=\"_blank\" href=\"%s\">la documentacion</a> e sus <a target=\"_blank\" href=\"http://owncloud.org\">nòstre site web</a>.",
    "If you like ownCloud,\n\t<a href=\"mailto:?subject=ownCloud\n\t\t&body=ownCloud is a great open software to sync and share your files.\n\t\tYou can freely get it from http://owncloud.org\">\n\t\trecommend it to your friends</a>\n\tand <a href=\"http://owncloud.org/promote\"\n\t\ttarget=\"_blank\">spread the word</a>!" : "Se vos agrada ownCloud,\n\t<a href=\"mailto:?subject=ownCloud\n\t\t&body=ownCloud es un supèrbe logicial liure per sincronizar e partejar vòstres fichièrs. \n\t\tLo podètz obténer gratuitament sus http://owncloud.org\">\n\t\tRecomandatz-lo a vòstres amics</a>\n\te <a href=\"http://owncloud.org/promote\"\n\t\ttarget=\"_blank\">fasètz passar l'informacion</a> !"
},
"nplurals=2; plural=(n > 1);");
