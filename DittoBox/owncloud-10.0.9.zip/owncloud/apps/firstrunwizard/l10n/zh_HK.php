<?php
$TRANSLATIONS = array(
"Connect your Calendar" => "連接您的日曆",
"Documentation" => "文件"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
